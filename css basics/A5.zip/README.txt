ASSIGNMENT 5 - HTML + CSS ONLY

01_portfolio.css
01_portfolio.html
02_city.css
02_city.html
03_team.css
03_team.html
04_article.css
04_article.html
05_pricing.css
05_pricing.html
06_gallery.css
06_gallery.html
07_contact.css
07_contact.html
08_dashboard.css
08_dashboard.html
09_newspaper.css
09_newspaper.html
10_complete_layout.css
10_complete_layout.html
