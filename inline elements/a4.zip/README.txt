ASSIGNMENT 3 - HTML ONLY

1. 01_resume.html
2. 02_product_catalog.html
3. 03_course_registration.html
4. 04_company_layout.html
5. 05_university_nested_list.html
6. 06_restaurant_menu.html
7. 07_conference_schedule.html
8. 08_student_report.html
9. 09_travel_destinations.html
10. 10_dropdown_selection.html
11. 11_news_layout.html
12. 12_quotation_showcase.html
13. 13_blog_layout.html
14. 14_movie_database.html
15. 15_portfolio_layout.html
